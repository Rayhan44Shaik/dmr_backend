import React, { useState, useMemo, useCallback } from 'react';
import { format, subDays } from 'date-fns';
import { TrendingUp, Truck, ShoppingBag, CreditCard, BookOpen, FileText } from 'lucide-react';
import type { ReportFilters, ReportType } from '../types/reportTypes';
import { getReportData } from '../services/reportService';
import ReportFiltersComponent from '../components/ReportFilters';
import ReportCard from '../components/ReportCard';
import ShopLedgerPage from './ShopLedgerPage';

// ========== IMPORTS ==========
import { useSafeNotification } from '../../../hooks/useSafeNotification';
import { useVehicles } from '../../masters/vehicles/hooks/useVehicles';
import { useEmployees } from '../../masters/employees/hooks/useEmployees';
import { useShops } from '../../masters/shops/hooks/useShops';
import { exportToPDF, exportToExcel } from '../../../utils/exportUtils';

// ========== REPORT CONFIGURATIONS & ICONS ==========
const tabs = [
  { key: 'shopLedger', label: 'Shop Ledger', icon: BookOpen, color: 'text-purple-500' },
  // other tabs can be uncommented if needed
  //{ key: 'weekly', label: 'Weekly Report', icon: TrendingUp, color: 'text-amber-500' },
  //{ key: 'vehicle', label: 'Vehicle Report', icon: Truck, color: 'text-blue-500' },
  //{ key: 'shopSales', label: 'Shop Sales', icon: ShoppingBag, color: 'text-emerald-500' },
  //{ key: 'collection', label: 'Collection Report', icon: CreditCard, color: 'text-teal-500' },
  //{ key: 'expenses', label: 'Expenses Report', icon: FileText, color: 'text-rose-500' },
] as const;

const REPORT_LABELS: Record<ReportType, string> = {
  weekly: 'Weekly Report',
  vehicle: 'Vehicle Report',
  shopSales: 'Shop Sales Report',
  collection: 'Collection Report',
  shopLedger: 'Shop Ledger',
  expenses: 'Expenses Report',
};

const REPORT_DESCRIPTIONS: Record<ReportType, string> = {
  weekly: 'Complete business summary for the selected week',
  vehicle: 'Detailed report for all vehicles and trips',
  shopSales: 'Sales details for all shops for selected period',
  collection: 'Collection details for all shops and collectors',
  shopLedger: 'Individual shop ledger with sales & collections',
  expenses: 'All business expenses report for selected period',
};

const REPORT_INCLUDES: Record<ReportType, string[]> = {
  weekly: ['Sales, Collections & Outstanding Summary', 'Trips, Birds, Mortality Summary', 'Expense Summary (Fuel, Maintenance, Fastag, Office)', 'Profit & Loss Summary'],
  vehicle: ['Trip Summary (Vehicle Wise)', 'KM Summary & Distance', 'Fuel Consumption & Expense', 'Maintenance, Fastag, Insurance & Permit', 'Vehicle Availability & Status'],
  shopSales: ['Shop Wise Sales Summary', 'Daily Sales Breakdown', 'Birds, Weight, Boxes, Amount', 'Sales Comparison', 'Top Performing Shops'],
  collection: ['Collection Register', 'Shop Wise Collection Summary', 'Collector Wise Collection', 'Payment Mode Wise Collection', 'Pending vs Collected Summary'],
  shopLedger: ['Opening Balance', 'Sales (Debit)', 'Collections (Credit)', 'Running Balance', 'Closing Balance & Outstanding'],
  expenses: ['Fuel Expense', 'Vehicle Maintenance Expense', 'Fastag Expense', 'Office Expense', 'Insurance & Permit Expense', 'Total Expense Summary'],
};

// ========== DEFAULT FILTERS ==========
const getDefaultFilters = (type: ReportType): ReportFilters => {
  const now = new Date();
  const sevenDaysAgo = subDays(now, 7);
  const common = {
    dateFrom: format(sevenDaysAgo, 'yyyy-MM-dd'),
    dateTo: format(now, 'yyyy-MM-dd'),
    format: 'PDF' as const,
    includeCharts: true,
  };
  switch (type) {
    case 'weekly':
      return { ...common, includeSections: ['Sales Summary', 'Collections Summary', 'Trips, Birds & Mortality'] };
    case 'vehicle':
      return { ...common, vehicle: 'All Vehicles', driver: 'All Drivers', tripStatus: 'All' };
    case 'shopSales':
      return { ...common, shop: 'All Shops', groupBy: 'Shop' };
    case 'collection':
      return { ...common, shop: 'All Shops', collector: 'All Collectors', paymentMode: 'All' };
    case 'shopLedger':
      return { ...common, shop: 'All Shops', groupBy: 'Shop' };
    case 'expenses':
      return { ...common, groupBy: 'Category' };
    default:
      return common;
  }
};

// ========== MAIN COMPONENT ==========
type ReportsDashboardPageProps = { embedded?: boolean };

const ReportsDashboardPage: React.FC<ReportsDashboardPageProps> = React.memo(({ embedded = false }) => {
  const { showNotification } = useSafeNotification();

  const { vehicles } = useVehicles();
  const { employees } = useEmployees();
  const { shops } = useShops();

  // ✅ Set default to 'shopLedger'
  const [selectedReport, setSelectedReport] = useState<ReportType>('shopLedger');
  const [filters, setFilters] = useState<ReportFilters>(getDefaultFilters('shopLedger'));

  const vehicleOptions = useMemo(
    () => [
      { value: 'All Vehicles', label: 'All Vehicles' },
      ...vehicles.map((v: any) => ({ value: v.vehicleNumber, label: v.vehicleNumber })),
    ],
    [vehicles]
  );

  const driverOptions = useMemo(
    () => [
      { value: 'All Drivers', label: 'All Drivers' },
      ...employees
        .filter((e: any) => e.department === 'Driver')
        .map((e: any) => ({ value: e.employeeName, label: e.employeeName })),
    ],
    [employees]
  );

  const collectorOptions = useMemo(
    () => [
      { value: 'All Collectors', label: 'All Collectors' },
      ...employees
        .filter((e: any) => e.department === 'Collection')
        .map((e: any) => ({ value: e.employeeName, label: e.employeeName })),
    ],
    [employees]
  );

  const shopOptions = useMemo(
    () => [
      { value: 'All Shops', label: 'All Shops' },
      ...shops.map((s: any) => ({ value: s.shopName, label: s.shopName })),
    ],
    [shops]
  );

  const handleTabChange = useCallback((type: ReportType) => {
    setSelectedReport(type);
    setFilters(getDefaultFilters(type));
  }, []);

  const reportData = useMemo(() => {
    // Skip fetching for shopLedger because we use custom component
    if (selectedReport === 'shopLedger') return null;
    try {
      return getReportData(selectedReport, filters);
    } catch (error) {
      console.error('Error generating report:', error);
      return null;
    }
  }, [selectedReport, filters]);

  const isDataAvailable = useMemo(() => {
    if (!reportData) return false;
    if (reportData.isEmpty !== undefined) return !reportData.isEmpty;
    if (reportData.details) {
      if (Array.isArray(reportData.details)) return reportData.details.length > 0;
      return Object.keys(reportData.details).length > 0;
    }
    return Object.keys(reportData.summary || {}).length > 0;
  }, [reportData]);

  const handleExport = useCallback(
    (formatType: 'PDF' | 'Excel') => {
      if (!reportData || !isDataAvailable) {
        showNotification('No data to export. Please adjust filters.', 'error');
        return;
      }

      try {
        const headers = ['Metric', 'Value'];
        const rows = Object.entries(reportData.summary).map(([key, value]) => [key, String(value)]);
        const filename = `${selectedReport}_${format(new Date(), 'yyyy-MM-dd')}`;
        const title = REPORT_LABELS[selectedReport];

        if (formatType === 'PDF') {
          exportToPDF(title, headers, rows, filename);
        } else {
          exportToExcel(title, headers, rows, filename);
        }
        showNotification(`Report downloaded as ${formatType}`, 'success');
      } catch (error) {
        console.error('Export error:', error);
        showNotification('Failed to generate report. Please try again.', 'error');
      }
    },
    [reportData, selectedReport, isDataAvailable, showNotification]
  );

  const content = (
    <div className="w-full pt-3 pb-6 space-y-4">
      {/* Tab Navigation */}
      <div className="bg-white border-y sm:border border-slate-200/90 sm:rounded-xl shadow-sm px-3 py-1.5 w-full">
        <div className="flex items-center gap-1 overflow-x-auto scrollbar-none [ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = selectedReport === tab.key;
            return (
              <button
                key={tab.key}
                type="button"
                onClick={() => handleTabChange(tab.key as ReportType)}
                className={`
                  flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all duration-200 shrink-0 cursor-pointer
                  ${
                    isActive
                      ? "bg-blue-50 text-blue-700 font-semibold"
                      : "text-slate-600 hover:text-slate-900 hover:bg-slate-50"
                  }
                `}
              >
                <Icon size={18} className={isActive ? "text-blue-700" : tab.color} />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Content */}
      <div className="w-full px-4 sm:px-6 lg:px-8 space-y-6">
        {selectedReport === 'shopLedger' ? (
          <ShopLedgerPage embedded={true} />
        ) : (
          <>
            <ReportFiltersComponent
              reportType={selectedReport}
              filters={filters}
              setFilters={setFilters}
              vehicleOptions={vehicleOptions}
              driverOptions={driverOptions}
              shopOptions={shopOptions}
              collectorOptions={collectorOptions}
            />
            <ReportCard
              title={REPORT_LABELS[selectedReport]}
              description={REPORT_DESCRIPTIONS[selectedReport]}
              includeList={REPORT_INCLUDES[selectedReport]}
              onDownloadPDF={() => handleExport('PDF')}
              onDownloadExcel={() => handleExport('Excel')}
              isDataAvailable={isDataAvailable}
            />
          </>
        )}
      </div>
    </div>
  );

  if (embedded) return content;
  return <div className="max-w-7xl mx-auto">{content}</div>;
});

export default ReportsDashboardPage;